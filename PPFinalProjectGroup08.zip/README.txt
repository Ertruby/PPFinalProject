How to compile a piece of Potato code:
- save it in a .txt file (preferably in the map input)
- execute Main.hs (you need haskell of course)
- type in: compile *file path as string* --> compile "input/test0.txt"
- open the output file in the map output to see the generated sprockel code
- to run the generated files, use GHC/GHCI in the src folder --> GHCI "output/Test0.hs" and call the main
